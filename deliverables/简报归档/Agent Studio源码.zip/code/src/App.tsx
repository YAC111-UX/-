import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { FormEvent } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  Activity, ArrowUp, Check, ChevronDown, ChevronRight, CircleHelp,
  Command, Download, FileText, Globe2, LoaderCircle, LockKeyhole,
  MessageSquare, MoreHorizontal, PanelLeftClose, Plus, Search, Settings2,
  ShieldCheck, Sparkles, Square, Sun, Trash2, X, Zap,
} from "lucide-react";
import type { AgentSettings, ChatEvent, ChatMessage, Conversation } from "./env";

const starters = [
  { icon: <Zap size={15} />, title: "算一笔账", prompt: "帮我计算 1280 × 1.08 + 350 的结果，并展示计算过程。" },
  { icon: <Globe2 size={15} />, title: "查查资料", prompt: "搜索近期有关 AI Agent 的产品和技术动态，整理 3 条并附来源链接。" },
  { icon: <Sun size={15} />, title: "看看天气", prompt: "查一下上海今天的天气，给我穿衣建议。" },
  { icon: <FileText size={15} />, title: "整理便签", prompt: "把这周要完成的三件事保存为便签：整理项目资料、完成演示稿、安排周五复盘。" },
];

const toolNames: Record<string, string> = {
  calculator: "计算器", current_time: "本地时间", weather: "实时天气",
  search_web: "网页搜索", save_note: "保存便签", list_notes: "检索便签",
};

function timeLabel(value: string) {
  const date = new Date(value);
  return date.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" });
}

function groupLabel(value: string) {
  const today = new Date().toDateString();
  return new Date(value).toDateString() === today ? "今天" : "最近对话";
}

export default function App() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState("");
  const [settings, setSettings] = useState<AgentSettings | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [draft, setDraft] = useState("");
  const [stream, setStream] = useState("");
  const [isRunning, setIsRunning] = useState(false);
  const [runId, setRunId] = useState("");
  const [tools, setTools] = useState<{ id: string; name: string; status: "working" | "done" }[]>([]);
  const [error, setError] = useState("");
  const [collapsed, setCollapsed] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [showToolDetails, setShowToolDetails] = useState(true);
  const [pendingUser, setPendingUser] = useState<ChatMessage | null>(null);
  const [openMenu, setOpenMenu] = useState(false);
  const [toast, setToast] = useState("");
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const activeIdRef = useRef(activeId);
  const fileName = useMemo(() => window.navigator.platform.toLowerCase().includes("mac") ? "⌘" : "Ctrl", []);

  useEffect(() => { activeIdRef.current = activeId; }, [activeId]);

  const active = conversations.find((item) => item.id === activeId);
  const messages = active?.messages || [];

  const refresh = useCallback(async (selectNewest = false) => {
    const [items, prefs] = await Promise.all([window.agentAPI.getConversations(), window.agentAPI.getSettings()]);
    setConversations(items);
    setSettings(prefs);
    if (selectNewest && items[0]) setActiveId(items[0].id);
    else if (!activeId && items[0]) setActiveId(items[0].id);
  }, [activeId]);

  useEffect(() => { void refresh(); }, [refresh]);

  useEffect(() => {
    const off = window.agentAPI.onChatEvent((event: ChatEvent) => {
      if (event.conversationId !== activeIdRef.current) return;
      if (event.type === "started") {
        setIsRunning(true);
        setRunId(event.conversationId);
        setError("");
        setStream("");
        setTools([]);
      } else if (event.type === "token") {
        setStream((current) => current + String(event.delta || ""));
      } else if (event.type === "draft") {
        setStream("");
        setTools((current) => [...current, { id: crypto.randomUUID(), name: "agent_note", status: "done" }]);
      } else if (event.type === "tool:start") {
        setTools((current) => [...current, { id: crypto.randomUUID(), name: String(event.tool || ""), status: "working" }]);
      } else if (event.type === "tool:done") {
        setTools((current) => current.map((item) => item.name === event.tool && item.status === "working" ? { ...item, status: "done" } : item));
      } else if (event.type === "done") {
        setStream("");
        setIsRunning(false);
        setPendingUser(null);
        void refresh();
      } else if (event.type === "stopped") {
        setStream("");
        setIsRunning(false);
        setPendingUser(null);
        void refresh();
      } else if (event.type === "error") {
        setStream("");
        setIsRunning(false);
        setPendingUser(null);
        setError(String(event.message || "请求失败"));
        void refresh();
      }
    });
    return off;
  }, [activeId, refresh]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length, stream, tools.length, activeId]);

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      const command = event.metaKey || event.ctrlKey;
      if (command && event.key.toLowerCase() === "k") { event.preventDefault(); setSearchOpen(true); }
      if (command && event.key.toLowerCase() === "n") { event.preventDefault(); void newConversation(); }
      if (event.key === "Escape") { setSearchOpen(false); setSettingsOpen(false); setOpenMenu(false); }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  });

  const newConversation = async () => {
    const item = await window.agentAPI.createConversation();
    activeIdRef.current = item.id;
    setConversations((current) => [item, ...current]);
    setActiveId(item.id);
    setDraft("");
    setStream("");
    setTools([]);
    setError("");
    setPendingUser(null);
    inputRef.current?.focus();
  };

  const submit = async (value = draft) => {
    const text = value.trim();
    if (!text || isRunning) return;
    if (!settings?.hasApiKey) { setSettingsOpen(true); setError("请先连接模型 API，再开始对话。"); return; }
    let id = activeId;
    if (!id) {
      const item = await window.agentAPI.createConversation();
      id = item.id;
      activeIdRef.current = id;
      setActiveId(id);
      setConversations((current) => [item, ...current]);
    }
    setDraft("");
    setError("");
    setPendingUser({ id: `pending-${Date.now()}`, role: "user", content: text, createdAt: new Date().toISOString() });
    setIsRunning(true);
    setRunId(id);
    setTools([]);
    try {
      await window.agentAPI.sendMessage(id, text);
      await refresh();
    } catch (reason) {
      setIsRunning(false);
      setPendingUser(null);
      setError(reason instanceof Error ? reason.message : "发送失败");
    }
  };

  const stop = async () => { if (runId) await window.agentAPI.stopMessage(runId); };

  const savePreferences = async (value: Partial<AgentSettings> & { apiKey?: string; clearApiKey?: boolean }) => {
    const updated = await window.agentAPI.saveSettings(value);
    setSettings(updated);
    setSettingsOpen(false);
    setToast("连接设置已保存");
    window.setTimeout(() => setToast(""), 2600);
  };

  const removeConversation = async (id: string) => {
    await window.agentAPI.deleteConversation(id);
    const remaining = conversations.filter((item) => item.id !== id);
    setConversations(remaining);
    if (activeId === id) { activeIdRef.current = remaining[0]?.id || ""; setActiveId(remaining[0]?.id || ""); setError(""); setPendingUser(null); }
    setOpenMenu(false);
  };

  const renameActive = async () => {
    if (!active) return;
    const title = window.prompt("设置对话名称", active.title);
    if (!title?.trim()) return;
    const updated = await window.agentAPI.renameConversation(active.id, title);
    setConversations((current) => current.map((item) => item.id === updated.id ? updated : item));
    setOpenMenu(false);
  };

  const filtered = conversations;
  const sections = filtered.reduce<Record<string, Conversation[]>>((result, item) => {
    const key = groupLabel(item.updatedAt);
    (result[key] ||= []).push(item);
    return result;
  }, {});

  return (
    <div className={`app-shell ${collapsed ? "sidebar-collapsed" : ""}`}>
      <aside className="sidebar">
        <div className="sidebar-top">
          <div className="brand-lockup">
            <div className="brand-mark"><span>A</span><i /></div>
            {!collapsed && <div><div className="brand-name">agent studio</div><div className="brand-meta">DESKTOP WORKSPACE</div></div>}
          </div>
          <button className="icon-button sidebar-toggle" aria-label="折叠侧栏" onClick={() => setCollapsed(!collapsed)}><PanelLeftClose size={17} /></button>
        </div>

        <div className="sidebar-actions">
          <button className="new-chat-button" onClick={() => void newConversation()} title="新建对话">
            <Plus size={16} /><span>新建对话</span><kbd>{fileName} N</kbd>
          </button>
          <button className={`side-action ${searchOpen ? "active" : ""}`} onClick={() => setSearchOpen(true)}><Search size={16} /><span>搜索对话</span><kbd>{fileName} K</kbd></button>
        </div>

        {!collapsed && <div className="conversation-list">
          <div className="list-heading"><span>工作区</span><button aria-label="刷新对话" className="tiny-icon" onClick={() => void refresh()}><MoreHorizontal size={16} /></button></div>
          {Object.keys(sections).length === 0 ? <div className="empty-list">还没有对话<br /><span>新建一个开始探索</span></div> : Object.entries(sections).map(([label, items]) => (
            <section key={label} className="chat-group">
              <div className="group-label">{label}</div>
              {items.map((item) => <button key={item.id} className={`chat-row ${item.id === activeId ? "selected" : ""}`} onClick={() => { activeIdRef.current = item.id; setActiveId(item.id); setError(""); setPendingUser(null); }}>
                <MessageSquare size={15} /><span>{item.title}</span><span className="row-time">{timeLabel(item.updatedAt)}</span>
              </button>)}
            </section>
          ))}
        </div>}

        <div className="sidebar-footer">
          {!collapsed && <div className="privacy-card">
            <div className="privacy-icon"><ShieldCheck size={17} /></div>
            <div><strong>数据留在本机</strong><span>Key 已由系统加密</span></div>
            <LockKeyhole size={14} className="privacy-lock" />
          </div>}
          <button className="profile-button" onClick={() => setSettingsOpen(true)}>
            <div className="profile-avatar">AS</div>
            {!collapsed && <><span className="profile-copy"><strong>本地工作区</strong><small>{settings?.provider || "正在加载"}</small></span><Settings2 size={17} className="profile-settings" /></>}
          </button>
        </div>
      </aside>

      <main className="main-panel">
        <header className="topbar">
          <div className="breadcrumb"><span>工作区</span><ChevronRight size={14} /><strong>{active?.title || "新对话"}</strong></div>
          <div className="topbar-tools">
            <span className={`connection-state ${settings?.hasApiKey ? "ready" : "setup-needed"}`}><span className="state-dot" />{settings?.hasApiKey ? "模型已连接" : "等待配置"}</span>
            <div className="topbar-divider" />
            <button className="top-icon" title="导出对话" disabled={!active} onClick={() => void window.agentAPI.exportConversation(activeId)}><Download size={17} /></button>
            <button className="top-icon" title="更多操作" disabled={!active} onClick={() => setOpenMenu(!openMenu)}><MoreHorizontal size={18} /></button>
            <button className="settings-button" onClick={() => setSettingsOpen(true)}><Settings2 size={15} /><span>设置</span></button>
            {openMenu && active && <div className="conversation-menu"><button onClick={() => void renameActive()}><MessageSquare size={14} />重命名对话</button><button className="danger" onClick={() => { if (window.confirm("确定删除这条对话吗？")) void removeConversation(active.id); }}><Trash2 size={14} />删除对话</button></div>}
          </div>
        </header>

        <div className="conversation-stage">
          {!messages.length && !pendingUser ? <div className="welcome-wrap">
            <div className="welcome-eyebrow"><span className="eyebrow-orb"><Sparkles size={13} /></span><span>你的本地 AI 工作台</span><span className="eyebrow-line" /></div>
            <h1>把想法交给 <em>Agent</em><br />让行动跟上思考</h1>
            <p className="welcome-description">连接你喜欢的模型。让 Agent 搜索、计算、整理，再把答案清晰地交还给你。</p>
            {!settings?.hasApiKey && <button className="connect-banner" onClick={() => setSettingsOpen(true)}>
              <div className="connect-banner-icon"><Zap size={16} /></div><div className="connect-banner-copy"><strong>连接你的模型服务</strong><span>添加 API Key 后开始对话，密钥使用系统加密保存</span></div><ChevronRight size={17} />
            </button>}
            <div className="starter-grid">
              {starters.map((item) => <button className="starter-card" key={item.title} onClick={() => { if (!settings?.hasApiKey) setSettingsOpen(true); else { void submit(item.prompt); } }}>
                <span className="starter-icon">{item.icon}</span><strong>{item.title}</strong><span className="starter-arrow"><ArrowUp size={13} /></span><small>{item.prompt.slice(0, 41)}…</small>
              </button>)}
            </div>
            <div className="workspace-note"><span><LockKeyhole size={13} /> 本地优先</span><i />消息与便签保存在此设备<span className="note-separator">·</span>模型请求直接从桌面端发出</div>
          </div> : <div className="thread-wrap">
            <div className="thread-topline"><span className="thread-chip"><Activity size={13} /> AGENT SESSION</span><span className="thread-date">{active ? new Date(active.createdAt).toLocaleDateString("zh-CN", { year: "numeric", month: "long", day: "numeric" }) : ""}</span></div>
            {messages.map((message) => <Message key={message.id} message={message} />)}
            {pendingUser && !messages.some((item) => item.role === "user" && item.content === pendingUser.content) && <Message message={pendingUser} />}
            {!!tools.length && <div className="tool-stack">
              <button className="tool-stack-header" onClick={() => setShowToolDetails(!showToolDetails)}>
                <span className={`tool-stack-spark ${isRunning ? "working" : ""}`}><Sparkles size={14} /></span>
                <strong>{isRunning ? "Agent 正在行动" : "Agent 已完成操作"}</strong>
                <span className="tool-count">{tools.filter((item) => item.name !== "agent_note").length} 项工具活动</span>
                <ChevronDown size={15} className={showToolDetails ? "" : "rotated"} />
              </button>
              {showToolDetails && <div className="tool-stack-list">{tools.filter((item) => item.name !== "agent_note").map((item) => <div className="tool-line" key={item.id}>
                <span className={`tool-status ${item.status}`}>{item.status === "working" ? <LoaderCircle size={13} /> : <Check size={12} />}</span>
                <span>{toolNames[item.name] || item.name}</span><span className="tool-line-detail">{item.status === "working" ? "正在运行" : "已完成"}</span>
              </div>)}</div>}
            </div>}
            {!!stream && <div className="message-row assistant-row"><div className="assistant-mark"><Sparkles size={15} /></div><div className="message-content"><div className="message-meta"><strong>Agent</strong><span>正在生成</span></div><Markdown text={stream} /><span className="typing-caret" /></div></div>}
            {isRunning && !stream && <div className="thinking-row"><span className="thinking-icon"><Sparkles size={14} /></span><span>Agent 正在思考</span><span className="thinking-dots"><i /><i /><i /></span></div>}
            {error && <div className="error-card"><CircleHelp size={16} /><span>{error}</span>{error.includes("API Key") && <button onClick={() => setSettingsOpen(true)}>打开设置</button>}</div>}
            <div ref={bottomRef} />
          </div>}
        </div>

        <div className="composer-area">
          <form className="composer" onSubmit={(event) => { event.preventDefault(); if (isRunning) void stop(); else void submit(); }}>
            <textarea ref={inputRef} rows={1} value={draft} onChange={(event) => { setDraft(event.target.value); event.currentTarget.style.height = "auto"; event.currentTarget.style.height = `${Math.min(event.currentTarget.scrollHeight, 180)}px`; }} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) { event.preventDefault(); if (isRunning) void stop(); else void submit(); } }} placeholder={settings?.hasApiKey ? "向 Agent 描述你想完成的事…" : "先连接模型服务，然后开始对话"} disabled={!settings?.hasApiKey && !!settings} />
            <div className="composer-bottom">
              <div className="composer-hints"><button type="button" onClick={() => setSettingsOpen(true)}><Command size={13} /> {fileName} + K 搜索</button><span>Enter 发送</span></div>
              <button className={`send-button ${isRunning ? "stop-button" : ""}`} type="submit" disabled={!draft.trim() && !isRunning} aria-label={isRunning ? "停止生成" : "发送消息"}>{isRunning ? <Square size={13} fill="currentColor" /> : <ArrowUp size={17} />}</button>
            </div>
          </form>
          <div className="composer-footnote">Agent 可能会出错，请核对重要信息 <span>·</span> {settings?.model || "未选择模型"} <span>·</span> <button onClick={() => setSettingsOpen(true)}>管理连接</button></div>
        </div>
      </main>

      {searchOpen && <SearchDialog items={conversations} onClose={() => setSearchOpen(false)} onSelect={(id) => { setActiveId(id); setSearchOpen(false); }} />}
      {settingsOpen && <SettingsDialog settings={settings} onClose={() => setSettingsOpen(false)} onSave={savePreferences} />}
      {toast && <div className="toast"><Check size={15} />{toast}</div>}
    </div>
  );
}

function Message({ message }: { message: ChatMessage }) {
  const user = message.role === "user";
  return <div className={`message-row ${user ? "user-row" : "assistant-row"}`}>
    {!user && <div className="assistant-mark"><Sparkles size={15} /></div>}
    <div className="message-content">
      <div className="message-meta"><strong>{user ? "你" : "Agent"}</strong><span>{timeLabel(message.createdAt)}</span></div>
      {user ? <div className="user-message">{message.content}</div> : <Markdown text={message.content} />}
    </div>
  </div>;
}

function Markdown({ text }: { text: string }) {
  return <div className="markdown-body"><ReactMarkdown remarkPlugins={[remarkGfm]}>{text}</ReactMarkdown></div>;
}

function SearchDialog({ items, onClose, onSelect }: { items: Conversation[]; onClose: () => void; onSelect: (id: string) => void }) {
  const [value, setValue] = useState("");
  const filtered = items.filter((item) => item.title.toLocaleLowerCase().includes(value.toLocaleLowerCase()) || item.messages.some((message) => message.content.toLocaleLowerCase().includes(value.toLocaleLowerCase())));
  return <div className="overlay" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <div className="search-dialog">
      <div className="search-input-row"><Search size={17} /><input autoFocus value={value} onChange={(event) => setValue(event.target.value)} placeholder="搜索标题和消息内容…" /><kbd>ESC</kbd><button className="tiny-icon" onClick={onClose}><X size={16} /></button></div>
      <div className="search-results"><div className="search-result-heading">{value ? `${filtered.length} 条结果` : "最近对话"}</div>{filtered.length ? filtered.slice(0, 8).map((item) => <button className="search-result" key={item.id} onClick={() => onSelect(item.id)}><MessageSquare size={16} /><span><strong>{item.title}</strong><small>{item.messages.at(-1)?.content.slice(0, 70) || "空白对话"}</small></span><span className="search-result-date">{timeLabel(item.updatedAt)}</span></button>) : <div className="no-search-results">没有找到匹配的对话</div>}</div>
      <div className="search-footer"><span><kbd>↑</kbd><kbd>↓</kbd> 浏览结果</span><span><kbd>↵</kbd> 打开对话</span><span>本机搜索</span></div>
    </div>
  </div>;
}

function SettingsDialog({ settings, onClose, onSave }: { settings: AgentSettings | null; onClose: () => void; onSave: (value: Partial<AgentSettings> & { apiKey?: string; clearApiKey?: boolean }) => Promise<void> }) {
  const [provider, setProvider] = useState(settings?.provider || "Free GPT API");
  const [baseUrl, setBaseUrl] = useState(settings?.baseUrl || "https://free.v36.cm/v1");
  const [model, setModel] = useState(settings?.model || "gpt-4o-mini");
  const [apiKey, setApiKey] = useState("");
  const [temperature, setTemperature] = useState(settings?.temperature ?? 0.65);
  const [maxSteps, setMaxSteps] = useState(settings?.maxSteps ?? 5);
  const [clearApiKey, setClearApiKey] = useState(false);
  const [saving, setSaving] = useState(false);
  const [localError, setLocalError] = useState("");
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setSaving(true); setLocalError("");
    try { await onSave({ provider, baseUrl, model, temperature: Number(temperature), maxSteps: Number(maxSteps), apiKey, clearApiKey }); }
    catch (reason) { setLocalError(reason instanceof Error ? reason.message : "设置保存失败"); }
    finally { setSaving(false); }
  };
  return <div className="overlay" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <form className="settings-dialog" onSubmit={submit}>
      <header className="dialog-header"><div><span className="dialog-kicker">PREFERENCES</span><h2>连接你的模型</h2><p>选择 OpenAI 兼容接口，并安全保存访问凭据。</p></div><button type="button" className="icon-button" onClick={onClose}><X size={18} /></button></header>
      <div className="dialog-content">
        <label className="field-label">服务商名称<input value={provider} onChange={(event) => setProvider(event.target.value)} placeholder="例如 阿里云百炼" /></label>
        <label className="field-label">Base URL<input value={baseUrl} onChange={(event) => setBaseUrl(event.target.value)} placeholder="https://.../v1" required /><small>填写服务商提供的 OpenAI 兼容地址。</small></label>
        <label className="field-label">模型名称<input value={model} onChange={(event) => setModel(event.target.value)} placeholder="例如 qwen-plus" required /></label>
        <label className="field-label">API Key<div className="secret-field"><input type="password" value={apiKey} onChange={(event) => { setApiKey(event.target.value); setClearApiKey(false); }} placeholder={settings?.hasApiKey ? "已加密保存，留空表示保持不变" : "粘贴你的 API Key"} autoComplete="new-password" /><span className="secret-lock"><LockKeyhole size={14} />{settings?.hasApiKey && !apiKey ? "已保存" : "仅本机"}</span></div><small>由操作系统加密服务保存，不会发送给 Agent。</small></label>
        {settings?.hasApiKey && <label className="clear-key"><input type="checkbox" checked={clearApiKey} onChange={(event) => setClearApiKey(event.target.checked)} />清除已保存的 API Key</label>}
        <div className="setting-range-row"><label className="field-label">回答随机度 <span>{Number(temperature).toFixed(2)}</span><input type="range" min="0" max="1.2" step="0.05" value={temperature} onChange={(event) => setTemperature(Number(event.target.value))} /></label><label className="field-label">最大工具步骤 <span>{maxSteps}</span><input type="range" min="1" max="8" step="1" value={maxSteps} onChange={(event) => setMaxSteps(Number(event.target.value))} /></label></div>
        {localError && <div className="dialog-error"><CircleHelp size={15} />{localError}</div>}
      </div>
      <footer className="dialog-footer"><span><ShieldCheck size={15} /> 使用系统凭据加密</span><button type="button" className="cancel-button" onClick={onClose}>取消</button><button className="save-button" type="submit" disabled={saving}>{saving ? <LoaderCircle className="spin" size={15} /> : <Check size={15} />}保存连接</button></footer>
    </form>
  </div>;
}
