export {};

declare global {
  interface Window {
    agentAPI: {
      getSettings: () => Promise<AgentSettings>;
      saveSettings: (value: Partial<AgentSettings> & { apiKey?: string; clearApiKey?: boolean }) => Promise<AgentSettings>;
      getConversations: () => Promise<Conversation[]>;
      createConversation: () => Promise<Conversation>;
      renameConversation: (id: string, title: string) => Promise<Conversation>;
      deleteConversation: (id: string) => Promise<boolean>;
      sendMessage: (id: string, text: string) => Promise<boolean>;
      stopMessage: (id: string) => Promise<boolean>;
      exportConversation: (id: string) => Promise<boolean>;
      onChatEvent: (callback: (event: ChatEvent) => void) => () => void;
    };
  }
}

export type AgentSettings = {
  provider: string;
  baseUrl: string;
  model: string;
  temperature: number;
  maxSteps: number;
  hasApiKey: boolean;
};

export type ChatMessage = { id: string; role: "user" | "assistant"; content: string; createdAt: string };
export type Conversation = { id: string; title: string; createdAt: string; updatedAt: string; messages: ChatMessage[] };
export type ChatEvent = { conversationId: string; type: string; [key: string]: string };
