# Agent Studio

Agent Studio 是一款可在 Windows 与 macOS 运行的 AI Agent 桌面工作台。它支持流式对话、连续工具调用、本地会话检索与 Markdown 导出。模型通过 OpenAI 兼容接口连接，默认使用项目指定的 Free GPT API 与 `gpt-4o-mini`，也可换成其他兼容服务。

## 功能

- 流式聊天、停止生成、多轮工具调用和可展开的工具活动记录。
- 内置计算器、本机时间、城市天气、网页搜索、本地便签保存与检索。
- 会话保存在本机，支持新建、搜索、重命名、删除和 Markdown 导出。
- API Key 只在 Electron 主进程中读取，并通过 Windows DPAPI 或 macOS Keychain 加密保存。
- React 界面采用上下文隔离和关闭 Node 集成的 Electron 配置。

## 开发环境

- Node.js 22.12 或更新版本。
- pnpm 10 或更新版本。
- Windows 10/11 64 位，或 macOS 13（Ventura）及更新版本。
- 首次安装依赖需要网络；模型对话、网页搜索和天气查询也需要网络。

在项目的 `code` 目录运行：

```sh
pnpm install
pnpm dev
```

Windows 用户也可以用 PowerShell；macOS 用户可用 Terminal。两边命令相同。

## 配置模型

启动后打开右上角“设置”，填写服务商、Base URL、模型名称和 API Key。项目默认值如下：

```text
Base URL: https://free.v36.cm/v1
模型名称: gpt-4o-mini
```

请确认服务端当前开放了该模型并支持 OpenAI 兼容的流式输出与工具调用。第三方服务的可用模型、速率和免费策略可能变化；重要数据不建议发送给未经评估的服务。API Key 不要提交到版本库。设置中的密钥输入框留空时会保留现有密钥。

## 构建桌面安装包

在目标操作系统上构建对应安装包：

```sh
pnpm package:win
pnpm package:mac
```

Windows 生成 NSIS 安装程序，macOS 生成 DMG 与 ZIP。建议在 Windows 主机运行 Windows 构建命令，在 macOS 主机运行 macOS 构建命令。macOS 代码签名和公证需要开发者证书，本项目未内置签名证书。

## 数据与服务

聊天、便签和非敏感设置存储在 Electron 当前用户的 `userData` 目录中；API Key 单独加密保存。天气使用 Open-Meteo 公共服务，网页搜索使用 DuckDuckGo HTML 搜索页。此两项无需另配密钥，但依赖第三方服务可访问。

## 目录

```text
electron/main.cjs       窗口、IPC、模型请求、工具和本地持久化
electron/preload.cjs    暴露给界面的最小 IPC 接口
src/App.tsx             聊天界面和设置面板
src/styles.css          桌面工作台样式
```
