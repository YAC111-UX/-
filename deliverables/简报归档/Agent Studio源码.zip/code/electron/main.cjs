const { app, BrowserWindow, ipcMain, safeStorage, dialog, shell } = require("electron");
const fs = require("node:fs/promises");
const path = require("node:path");
const crypto = require("node:crypto");

const defaultSettings = {
  provider: "Free GPT API",
  baseUrl: "https://free.v36.cm/v1",
  model: "gpt-4o-mini",
  temperature: 0.65,
  maxSteps: 5,
};

let mainWindow;
const activeRuns = new Map();
const storeFile = () => path.join(app.getPath("userData"), "agent-studio.json");
const secretFile = () => path.join(app.getPath("userData"), "api-key.bin");

async function readStore() {
  try {
    const value = JSON.parse(await fs.readFile(storeFile(), "utf8"));
    return {
      settings: { ...defaultSettings, ...(value.settings || {}) },
      conversations: Array.isArray(value.conversations) ? value.conversations : [],
      notes: Array.isArray(value.notes) ? value.notes : [],
    };
  } catch {
    return { settings: { ...defaultSettings }, conversations: [], notes: [] };
  }
}

async function writeStore(value) {
  const target = storeFile();
  const temporary = `${target}.tmp`;
  await fs.mkdir(path.dirname(target), { recursive: true });
  await fs.writeFile(temporary, JSON.stringify(value, null, 2), "utf8");
  await fs.rename(temporary, target);
}

async function readApiKey() {
  try {
    const encrypted = await fs.readFile(secretFile());
    return safeStorage.decryptString(encrypted);
  } catch {
    return "";
  }
}

function publicSettings(settings, apiKey) {
  return { ...settings, hasApiKey: Boolean(apiKey) };
}

function validateSettings(input) {
  const baseUrl = String(input.baseUrl || "").trim().replace(/\/+$/, "");
  const model = String(input.model || "").trim();
  let endpoint;
  try {
    endpoint = new URL(baseUrl);
  } catch {
    throw new Error("Base URL 格式不正确");
  }
  if (endpoint.protocol !== "https:" && !(endpoint.protocol === "http:" && ["localhost", "127.0.0.1"].includes(endpoint.hostname))) {
    throw new Error("Base URL 必须使用 HTTPS；本地模型可使用 localhost");
  }
  if (!model || model.length > 120) throw new Error("请填写有效的模型名称");
  return {
    provider: String(input.provider || "自定义 OpenAI 兼容服务").trim().slice(0, 80),
    baseUrl,
    model,
    temperature: Math.min(1.2, Math.max(0, Number(input.temperature) || 0)),
    maxSteps: Math.min(8, Math.max(1, Number(input.maxSteps) || 5)),
  };
}

function emit(conversationId, type, data = {}) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send("chat:event", { conversationId, type, ...data });
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 1040,
    minHeight: 680,
    title: "Agent Studio",
    backgroundColor: "#f6f7f5",
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("https://")) shell.openExternal(url);
    return { action: "deny" };
  });
  mainWindow.webContents.on("will-navigate", (event, url) => {
    if (url.startsWith("https://")) {
      event.preventDefault();
      shell.openExternal(url);
    } else if (!url.startsWith("file://") && !url.startsWith("http://127.0.0.1:5173")) {
      event.preventDefault();
    }
  });
  if (!app.isPackaged) mainWindow.loadURL(process.env.VITE_DEV_SERVER_URL || "http://127.0.0.1:5173");
  else mainWindow.loadFile(path.join(__dirname, "../dist/index.html"));
}

app.whenReady().then(() => {
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

ipcMain.handle("settings:get", async () => {
  const store = await readStore();
  return publicSettings(store.settings, await readApiKey());
});

ipcMain.handle("settings:save", async (_event, input) => {
  const store = await readStore();
  const settings = validateSettings(input || {});
  if (input.clearApiKey) {
    await fs.rm(secretFile(), { force: true });
  } else if (String(input.apiKey || "").trim()) {
    if (!safeStorage.isEncryptionAvailable()) throw new Error("系统加密服务不可用，请检查 macOS 钥匙串或 Windows 用户配置");
    await fs.mkdir(path.dirname(secretFile()), { recursive: true });
    await fs.writeFile(secretFile(), safeStorage.encryptString(String(input.apiKey).trim()));
  }
  store.settings = settings;
  await writeStore(store);
  return publicSettings(settings, await readApiKey());
});

ipcMain.handle("conversations:list", async () => (await readStore()).conversations.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)));

ipcMain.handle("conversations:create", async () => {
  const store = await readStore();
  const conversation = { id: crypto.randomUUID(), title: "新对话", createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), messages: [] };
  store.conversations.unshift(conversation);
  await writeStore(store);
  return conversation;
});

ipcMain.handle("conversations:rename", async (_event, id, title) => {
  const store = await readStore();
  const conversation = store.conversations.find((item) => item.id === id);
  if (!conversation) throw new Error("找不到这条对话");
  conversation.title = String(title || "新对话").trim().slice(0, 80) || "新对话";
  conversation.updatedAt = new Date().toISOString();
  await writeStore(store);
  return conversation;
});

ipcMain.handle("conversations:delete", async (_event, id) => {
  activeRuns.get(id)?.abort();
  const store = await readStore();
  store.conversations = store.conversations.filter((item) => item.id !== id);
  await writeStore(store);
  return true;
});

ipcMain.handle("conversations:export", async (_event, id) => {
  const store = await readStore();
  const conversation = store.conversations.find((item) => item.id === id);
  if (!conversation) throw new Error("找不到这条对话");
  const result = await dialog.showSaveDialog(mainWindow, {
    defaultPath: `${conversation.title || "对话记录"}.md`,
    filters: [{ name: "Markdown", extensions: ["md"] }],
  });
  if (result.canceled || !result.filePath) return false;
  const body = conversation.messages.map((message) => `## ${message.role === "user" ? "你" : "Agent"}\n\n${message.content}`).join("\n\n---\n\n");
  await fs.writeFile(result.filePath, `# ${conversation.title}\n\n${body}\n`, "utf8");
  return true;
});

const toolSpecs = [
  { type: "function", function: { name: "calculator", description: "进行精确数值计算，支持四则运算、括号、幂运算。", parameters: { type: "object", properties: { expression: { type: "string", description: "纯数学表达式，例如 (1250+380)*0.18" } }, required: ["expression"], additionalProperties: false } } },
  { type: "function", function: { name: "current_time", description: "读取本机当前日期、时间及时区。", parameters: { type: "object", properties: {}, additionalProperties: false } } },
  { type: "function", function: { name: "weather", description: "查询指定城市的当前天气。", parameters: { type: "object", properties: { city: { type: "string", description: "城市名称，例如 Shanghai" } }, required: ["city"], additionalProperties: false } } },
  { type: "function", function: { name: "search_web", description: "搜索公开网页并返回标题、摘要和链接。", parameters: { type: "object", properties: { query: { type: "string", description: "清晰的搜索关键词" } }, required: ["query"], additionalProperties: false } } },
  { type: "function", function: { name: "save_note", description: "将用户明确要求保留的内容保存为本机便签。", parameters: { type: "object", properties: { title: { type: "string" }, content: { type: "string" } }, required: ["title", "content"], additionalProperties: false } } },
  { type: "function", function: { name: "list_notes", description: "查找本机便签。", parameters: { type: "object", properties: { query: { type: "string" } }, additionalProperties: false } } },
];

function decodeHtml(value) {
  return value.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;|&#x27;/gi, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&#(\d+);/g, (_all, code) => String.fromCodePoint(Number(code)));
}

function cleanHtml(value) {
  return decodeHtml(value.replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim());
}

async function runTool(name, input, conversationId) {
  if (name === "calculator") {
    const expression = String(input.expression || "").trim();
    if (!/^[\d\s()+\-*/%.^]+$/.test(expression)) throw new Error("只支持数字、括号和基本运算符");
    const jsExpression = expression.replace(/\^/g, "**");
    const result = Function(`"use strict"; return (${jsExpression})`)();
    if (!Number.isFinite(result)) throw new Error("计算结果不是有限数值");
    return { expression, result };
  }
  if (name === "current_time") {
    return { iso: new Date().toISOString(), local: new Date().toLocaleString("zh-CN", { dateStyle: "full", timeStyle: "long" }), timezone: Intl.DateTimeFormat().resolvedOptions().timeZone };
  }
  if (name === "weather") {
    const city = String(input.city || "").trim().slice(0, 80);
    if (!city) throw new Error("请提供城市名称");
    const placeUrl = new URL("https://geocoding-api.open-meteo.com/v1/search");
    placeUrl.search = new URLSearchParams({ name: city, count: "1", language: "zh", format: "json" }).toString();
    const placeResponse = await fetch(placeUrl, { signal: AbortSignal.timeout(12000) });
    if (!placeResponse.ok) throw new Error("天气地点服务暂时不可用");
    const place = (await placeResponse.json()).results?.[0];
    if (!place) throw new Error(`没有找到城市：${city}`);
    const forecastUrl = new URL("https://api.open-meteo.com/v1/forecast");
    forecastUrl.search = new URLSearchParams({ latitude: String(place.latitude), longitude: String(place.longitude), current: "temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m", timezone: "auto" }).toString();
    const forecastResponse = await fetch(forecastUrl, { signal: AbortSignal.timeout(12000) });
    if (!forecastResponse.ok) throw new Error("天气数据暂时不可用");
    const forecast = await forecastResponse.json();
    return { location: `${place.name}${place.admin1 ? `，${place.admin1}` : ""}${place.country ? `，${place.country}` : ""}`, current: forecast.current, units: forecast.current_units, observedAt: forecast.current?.time };
  }
  if (name === "search_web") {
    const query = String(input.query || "").trim().slice(0, 220);
    if (!query) throw new Error("请提供搜索关键词");
    const response = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`, { headers: { "User-Agent": "Mozilla/5.0 AgentStudio/1.0" }, signal: AbortSignal.timeout(15000) });
    if (!response.ok) throw new Error("网页搜索暂时不可用");
    const html = await response.text();
    const blocks = [...html.matchAll(/<div class="result[^>]*>([\s\S]*?)<\/div>\s*<\/div>/g)].map((match) => match[1]);
    const results = blocks.slice(0, 5).map((block) => {
      const title = block.match(/class="result__a"[^>]*>([\s\S]*?)<\/a>/i)?.[1] || "";
      const rawUrl = block.match(/class="result__a"[^>]*href="([^"]+)/i)?.[1] || "";
      const snippet = block.match(/class="result__snippet"[^>]*>([\s\S]*?)<\/a>/i)?.[1] || block.match(/class="result__snippet"[^>]*>([\s\S]*?)<\/div>/i)?.[1] || "";
      let url = decodeHtml(rawUrl);
      try { const parsed = new URL(url, "https://duckduckgo.com"); url = parsed.searchParams.get("uddg") ? decodeURIComponent(parsed.searchParams.get("uddg")) : parsed.href; } catch {}
      return { title: cleanHtml(title), url, snippet: cleanHtml(snippet) };
    }).filter((item) => item.title && item.url);
    return { query, results, note: results.length ? "请根据结果摘要回答，并保留链接。" : "没有解析到结果，可改写关键词后重试。" };
  }
  if (name === "save_note") {
    const store = await readStore();
    const title = String(input.title || "新便签").trim().slice(0, 100) || "新便签";
    const content = String(input.content || "").trim().slice(0, 6000);
    if (!content) throw new Error("便签内容不能为空");
    const note = { id: crypto.randomUUID(), title, content, updatedAt: new Date().toISOString() };
    store.notes.unshift(note);
    store.notes = store.notes.slice(0, 200);
    await writeStore(store);
    return { saved: true, title: note.title, id: note.id };
  }
  if (name === "list_notes") {
    const store = await readStore();
    const query = String(input.query || "").trim().toLocaleLowerCase();
    return store.notes.filter((note) => !query || `${note.title}\n${note.content}`.toLocaleLowerCase().includes(query)).slice(0, 12);
  }
  throw new Error(`未开放的工具：${name}`);
}

async function* parseSse(response, signal) {
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  while (true) {
    if (signal.aborted) throw new DOMException("用户停止了生成", "AbortError");
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split(/\r?\n/);
    buffer = lines.pop() || "";
    for (const line of lines) {
      if (!line.startsWith("data:")) continue;
      const payload = line.slice(5).trim();
      if (!payload || payload === "[DONE]") continue;
      yield JSON.parse(payload);
    }
  }
}

async function requestCompletion({ settings, apiKey, messages, signal, conversationId, toolChoice = "auto" }) {
  const endpoint = `${settings.baseUrl.replace(/\/+$/, "")}/chat/completions`;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ model: settings.model, stream: true, temperature: settings.temperature, messages, tools: toolSpecs, tool_choice: toolChoice }),
    signal,
  });
  if (!response.ok) {
    const detail = (await response.text()).slice(0, 600);
    throw new Error(`模型服务返回 ${response.status}：${detail || response.statusText}`);
  }
  const toolCalls = [];
  let content = "";
  for await (const chunk of parseSse(response, signal)) {
    const choice = chunk.choices?.[0];
    const delta = choice?.delta || {};
    if (delta.content) {
      content += delta.content;
      emit(conversationId, "token", { delta: delta.content });
    }
    for (const part of delta.tool_calls || []) {
      const index = part.index ?? toolCalls.length;
      if (!toolCalls[index]) toolCalls[index] = { id: "", type: "function", function: { name: "", arguments: "" } };
      if (part.id) toolCalls[index].id += part.id;
      if (part.function?.name) toolCalls[index].function.name += part.function.name;
      if (part.function?.arguments) toolCalls[index].function.arguments += part.function.arguments;
    }
  }
  return { content, toolCalls: toolCalls.filter(Boolean) };
}

async function runAgent(conversationId, text) {
  const controller = new AbortController();
  activeRuns.set(conversationId, controller);
  try {
    const store = await readStore();
    const conversation = store.conversations.find((item) => item.id === conversationId);
    if (!conversation) throw new Error("找不到这条对话");
    const apiKey = await readApiKey();
    if (!apiKey) throw new Error("请先打开设置并填写模型 API Key");
    conversation.messages.push({ id: crypto.randomUUID(), role: "user", content: text, createdAt: new Date().toISOString() });
    if (conversation.messages.filter((item) => item.role === "user").length === 1) conversation.title = text.trim().replace(/\s+/g, " ").slice(0, 34) || "新对话";
    conversation.updatedAt = new Date().toISOString();
    await writeStore(store);
    emit(conversationId, "started");
    const messages = [
      { role: "system", content: "你是 Agent Studio 中可靠、简洁的中文 AI 助手。先理解用户目标，再判断是否需要工具；计算、天气、实时网页信息和本地便签应调用对应工具，不要编造工具结果。工具失败时说明原因并给出可行替代。引用网页搜索结果时附上来源链接。保存便签只在用户提出保存或记录要求时执行。" },
      ...conversation.messages.map((item) => ({ role: item.role, content: item.content })),
    ];
    let finalText = "";
    for (let turn = 0; turn <= store.settings.maxSteps; turn += 1) {
      if (controller.signal.aborted) throw new DOMException("用户停止了生成", "AbortError");
      const mayUseTools = turn < store.settings.maxSteps;
      const completion = await requestCompletion({ settings: store.settings, apiKey, messages, signal: controller.signal, conversationId, toolChoice: mayUseTools ? "auto" : "none" });
      if (completion.toolCalls.length) {
        if (!mayUseTools) throw new Error("Agent 已达到最大工具步骤，请再发一条消息继续");
        if (completion.content) emit(conversationId, "draft", { content: completion.content });
        messages.push({ role: "assistant", content: completion.content || null, tool_calls: completion.toolCalls });
        for (const call of completion.toolCalls) {
          const toolName = call.function.name;
          let args;
          let result;
          try {
            args = JSON.parse(call.function.arguments || "{}");
            emit(conversationId, "tool:start", { tool: toolName, label: ({ calculator: "正在计算", current_time: "正在读取时间", weather: "正在查询天气", search_web: "正在搜索网页", save_note: "正在保存便签", list_notes: "正在查找便签" })[toolName] || "正在执行工具" });
            result = await runTool(toolName, args, conversationId);
          } catch (error) {
            result = { error: error.message || "工具执行失败" };
          }
          emit(conversationId, "tool:done", { tool: toolName, result: result?.error ? "执行失败" : "已完成" });
          messages.push({ role: "tool", tool_call_id: call.id, content: JSON.stringify(result) });
        }
        continue;
      }
      finalText = completion.content.trim();
      break;
    }
    if (!finalText && !controller.signal.aborted) finalText = "已完成工具处理，但响应没有生成文本。请再问我一次，我会继续整理结果。";
    if (finalText) {
      const latest = await readStore();
      const target = latest.conversations.find((item) => item.id === conversationId);
      if (target) {
        target.messages.push({ id: crypto.randomUUID(), role: "assistant", content: finalText, createdAt: new Date().toISOString() });
        target.updatedAt = new Date().toISOString();
        await writeStore(latest);
      }
      emit(conversationId, "done", { content: finalText });
    } else {
      emit(conversationId, "stopped");
    }
  } catch (error) {
    if (error.name === "AbortError") emit(conversationId, "stopped");
    else emit(conversationId, "error", { message: error.message || "请求失败" });
  } finally {
    activeRuns.delete(conversationId);
  }
}

ipcMain.handle("chat:send", async (_event, id, text) => {
  const conversationId = String(id || "");
  const prompt = String(text || "").trim();
  if (!prompt || prompt.length > 12000) throw new Error("消息不能为空或超过 12000 个字符");
  if (activeRuns.has(conversationId)) throw new Error("这条对话正在生成，请稍候或先停止");
  await runAgent(conversationId, prompt);
  return true;
});

ipcMain.handle("chat:stop", async (_event, id) => {
  activeRuns.get(String(id))?.abort();
  return true;
});
