const { contextBridge, ipcRenderer } = require("electron");

const subscribe = (channel, callback) => {
  const listener = (_event, data) => callback(data);
  ipcRenderer.on(channel, listener);
  return () => ipcRenderer.removeListener(channel, listener);
};

contextBridge.exposeInMainWorld("agentAPI", {
  getSettings: () => ipcRenderer.invoke("settings:get"),
  saveSettings: (value) => ipcRenderer.invoke("settings:save", value),
  getConversations: () => ipcRenderer.invoke("conversations:list"),
  createConversation: () => ipcRenderer.invoke("conversations:create"),
  renameConversation: (id, title) => ipcRenderer.invoke("conversations:rename", id, title),
  deleteConversation: (id) => ipcRenderer.invoke("conversations:delete", id),
  sendMessage: (id, text) => ipcRenderer.invoke("chat:send", id, text),
  stopMessage: (id) => ipcRenderer.invoke("chat:stop", id),
  exportConversation: (id) => ipcRenderer.invoke("conversations:export", id),
  onChatEvent: (callback) => subscribe("chat:event", callback),
});
